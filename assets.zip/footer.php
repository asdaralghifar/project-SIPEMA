<!DOCTYPE html>
<html lang="en">
<footer>
    <div class="container-fluid bg-dark text-white border-top py-4 px-sm-3 px-md-5" style="border-color: rgba(256, 256, 256, .1) !important;">
        <div class="row">
            <div class="col-lg-6 text-center text-md-left mb-3 mb-md-0" style="margin: 0 auto;">
                <center><p class="m-0 text-white">&copy; <a href="#">Diskominfo</a> Kota Kendari</a><center>
                </p>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="assets/lib/easing/easing.min.js"></script>
    <script src="assets/lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="assets1/mail/jqBootstrapValidation.min.js"></script>
    <script src="assets1/mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="assets1/js/main.js"></script>
</footer>

</html>