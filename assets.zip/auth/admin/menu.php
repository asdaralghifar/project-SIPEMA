<!DOCTYPE html>
<html lang="en">
<div class="sidebar sidebar-style-2">			
			<div class="sidebar-wrapper scrollbar scrollbar-inner">
				<div class="sidebar-content">
					
					<ul class="nav nav-primary">
						<li class="nav-item">
							<a href="index.php">
								<i class="fas fa-home"></i>
								<p>Dashboard</p>	
							</a>
						</li>
						<li class="nav-item">
							<a href="dmasjid.php">
								<i class="fas fa-table"></i>
								<p>Daftar Masjid/Musala</p>	
							</a>
						</li>
						<li class="mx-4 mt-2">
							<a href="../logout.php" class="btn btn-primary btn-block" onclick="return confirm('Apakah anda yakin ingin Log Out?')">Log Out</a> 
							
						</li>
					</ul>
				</div>
			</div>
</div>
</html>